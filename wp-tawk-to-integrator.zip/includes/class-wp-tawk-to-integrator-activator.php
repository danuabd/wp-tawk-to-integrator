<?php

/**
 * Fired during plugin activation
 *
 * @link       https://danukaprasad.com
 * @since      1.0.0
 *
 * @package    Wp_Tawk_To_Integrator
 * @subpackage Wp_Tawk_To_Integrator/includes
 * @author     ABD Prasad <contact@danukaprasad.com>
 */
class Wp_Tawk_To_Integrator_Activator
{
	private $options_key;

	/**
	 * Start from clean slate.
	 *
	 * Remove any previous plugin data if exists.
	 *
	 * @since    1.0.0
	 */
	public static function activate($options_key)
	{
		if ($options_key) {
			delete_option($options_key);
		}

		self::set_default_options($options_key);
	}

	/**
	 * Sets the default options for the plugin.
	 *
	 * This method defines the initial state of the plugin's settings
	 * and saves them to the database using the add_option function.
	 *
	 * @since 1.0.0
	 * @param string $options_key The key for the plugin's options in the database.
	 */
	public static function set_default_options($options_key)
	{
		// Define the array of default settings.
		$default_options = array(
			'property_id' => '',
			'widget_id' => '',
			'z_index' => '',
			'activate_widget_check' => '1',
			'pages_to_hide_input' => '',
			'hide_widget_admin_role_check' => '0',
			'hide_widget_editor_role_check' => '0',
			'hide_widget_author_role_check' => '0',
			'hide_widget_contributor_role_check' => '0',
			'hide_widget_subscriber_role_check' => '0',
			'hide_widget_customer_role_check' => '0',
			'show_widget_to_guest' => '1',
			'widget_maximize_element_input' => '',
			'auto_populate_userdata_check' => '0',
			'custom_attributes_input' => '',
			'secure_mode_check' => '0',
			'tawk_api_key_input' => '',
			'auto_page_tagging_check' => '0',
			'ignore_auto_tagging_input' => '',
			'action_based_targeting_check' => '0',
			'ignore_action_based_targeting_input' => '',
			'widget_onload_customize_check' => '0',
			'widget_render_delay_input' => '0',
			'custom_js_onload' => '',
			'chat_event_action_check' => '0',
			'custom_js_on_chat_started' => '',
			'custom_js_on_chat_ended_input' => '',
			'pre_chat_submit_action_check' => '0',
			'capture_pre_chat_data_check' => '0',
			'custom_js_on_chat_submit_input' => '',
		);

		// Add the option to the database.
		add_option($options_key, $default_options);
	}
}
